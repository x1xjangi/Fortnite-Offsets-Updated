Uworld: 48 89 05 ? ? ? ? 0F 28 D7 // WORKS
GObjects: 48 8B 05 ? ? ? ? 48 8B 0C C8 48 8B 04 D1 // WORKS
GNames: 48 8D 05 ? ? ? ? 48 83 C4 28 C3 48 8D 0D ? ? ? ? E8 ? ? ? ? C6 05 // WORKS
StaticFindObject: 48 89 5C 24 10 55 56 57 48 81 EC 40 04 // WORKS
//join my server to support me <3
//https://discord.gg/h-m
